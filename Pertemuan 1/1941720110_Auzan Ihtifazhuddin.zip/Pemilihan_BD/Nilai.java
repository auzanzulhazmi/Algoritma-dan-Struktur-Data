/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pemilihan_BD;
import java.util.Scanner;

/**
 *
 * @author ROG STRIX
 */
public class Nilai {
    public static void main(String[] args) {
        Scanner baca = new Scanner(System.in);
        int nilai_tugas, nilai_uts, nilai_uas;
        String nama;
        double na;

        System.out.println("----Menghitung Nilai Akhir (Nilai 0-100)----");
        System.out.println("--------------------------------------------");
        System.out.print("Nama Mahasiswa \t: ");
        nama = baca.nextLine();
        System.out.print("Nilai Tugas \t: ");
        nilai_tugas = baca.nextInt();
        if (nilai_tugas > 100 || nilai_tugas < 0) {
            System.out.println("Nilai yang dimasukkan salah");
        } else {
            System.out.print("Nilai UTS \t: ");
            nilai_uts = baca.nextInt();
            if (nilai_uts > 100 || nilai_uts < 0) {
                System.out.println("Nilai yang dimasukkan salah");
            } else {
                System.out.print("Nilai UAS \t: ");
                nilai_uas = baca.nextInt();
                if (nilai_uas > 100 || nilai_uas < 0) {
                    System.out.println("Nilai yang dimasukkan salah");
                } else {
                    na = (nilai_tugas * 0.2) + (nilai_uts * 0.35) + (nilai_uas * 0.45);
                    System.out.printf("Nilai Akhir \t: %.2f", na);
                    System.out.println();
                    System.out.println("--------------------------------------------");
                }
            }
        }

    }
}
